Download data.zip
